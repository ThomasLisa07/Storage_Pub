#include <stdio.h>

int main(void) {
  int n;

  do
    {
      printf("Inserisci la lunghezza del vettore: ");
      scanf("%i",&n);
    }
    while(n<=0);
  int a[n];
  for(int i=0;i<n;i++)
    {
      printf("Inserisci elemento: ");
      scanf("%i",&a[i]);
    }
  int i=0;
  while(a[i]>=a[i+1] && i>n-1)
    i++;
  if(a[i]<a[i+1])
    printf("Il vettore non è ordinato");
  else
    printf("Il vettore è ordinato");
  for(int i=0;i<n;i++)
    printf("\t%i",a[i]);
  return 0;
}